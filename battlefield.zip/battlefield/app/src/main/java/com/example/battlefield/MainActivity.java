package com.example.battlefield;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    Sensor accelerometer;
    SensorManager sensorManager;
    float sensorX, sensorY, sensorZ;
    int numEspaco = 0;
    String Xnave = "";
    String altura = "";
    String Xtiro = "";
    int Ytiro = 0;
    Boolean TiroEmAndamento = false;

    //****************** onCreate *************************************
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //****************** sensor *************************************
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener((SensorEventListener) this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        //****************** Listner do tiro *************************************
        Button tiro = (Button) findViewById(R.id.tiro);
        tiro.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if(!TiroEmAndamento) { // igual a pergunta "Ã‰ possivel disparar?"
                    Xtiro = Xnave; // Iguala o X do tiro ao nÃºmero de espÃ§os do personagem
                    Ytiro = 23; // Numero de linhas que o tiro precisa para chegar no topo da tela
                    TiroEmAndamento = true; // Informa que o tiro estÃ¡ em andamento

                    //****************** Gerador de som *************************************
                    ToneGenerator toneGen1 = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
                    toneGen1.startTone(ToneGenerator.TONE_CDMA_PIP,150);
                }
            }
        });
    }

    //****************** onSensorChanged *************************************
    @Override
    public void onSensorChanged(SensorEvent event) {
        sensorX = event.values[0];
        sensorY = event.values[1];
        sensorZ = event.values[2];

        //*********************** MovimentaÃ§Ã£o lateral Direita ******************************
        if (sensorX < 0 && numEspaco<80){
            numEspaco+=5;
            //*********************** MovimentaÃ§Ã£o lateral Esquerda ******************************
        }else if (sensorX > 0 && numEspaco >6){
            numEspaco-=5; }
        //****************************************************************************



        //*********** Monta os espaÃ§os (MovimentaÃ§Ã£o lateral do heroi) na variÃ¡vel tela *************************************
        Xnave = "";
        for(int i = 0; i <=numEspaco; i++){
            Xnave = Xnave +" ";
        }

        //*********** Tratamento do andamento do tiro *************************************
        if (TiroEmAndamento) {
            Ytiro--;
            if (Ytiro <= 8) { // Zera o tiro
                TiroEmAndamento = false;
                Ytiro = 23;
            }
        }
        //*********** Monta as 24 quebras de linha (MovimentaÃ§Ã£o vertical) na variÃ¡vel altura *************************************
        altura = ""; //*** Zera a altura
        for(int i = 0; i <=23; i++){
            if (TiroEmAndamento){ //***** Verifica se tiro estÃ¡ ativo *****
                if(Ytiro == i) // se a iteraÃ§Ã£o for igual a posiÃ§Ã£o Y do tiro...
                    altura = altura + Xtiro + "* \n";
                else
                    altura = altura +" \n";
            }
            else
                altura = altura +" \n";
        }


        //****************** Monta a tela *************************************
        //*********************************************************************
        //*********************** Campo de batalha ******************************
        EditText Player = (EditText) findViewById(R.id.Player);
        Player.setText(altura+Xnave+"A");
        //*********************************************************************
        //*********************************************************************
        //*********************************************************************
    }

    //****************** onAccuracyChanged *************************************
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

}